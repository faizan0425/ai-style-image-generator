import React from "react";
import StyleImageGenerator from "./StyleImageGenerator";

function App() {
  return <StyleImageGenerator />;
}

export default App;
