import React, { useState } from "react";

export default function StyleImageGenerator() {
  const [image, setImage] = useState(null);
  const [style, setStyle] = useState("Ghibli");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleImageChange = (e) => {
    setImage(e.target.files[0]);
    setResult(null);
  };

  const handleGenerate = async () => {
    if (!image) return;
    setLoading(true);

    setTimeout(() => {
      setResult("/placeholder-result.jpg");
      setLoading(false);
    }, 2000);
  };

  return (
    <div style={{ padding: "2rem", maxWidth: "600px", margin: "auto" }}>
      <h1 style={{ fontSize: "24px", fontWeight: "bold", marginBottom: "1rem" }}>
        AI Style Image Generator
      </h1>

      <div style={{ marginBottom: "1rem", padding: "1rem", border: "1px solid #ccc", borderRadius: "8px" }}>
        <input type="file" accept="image/*" onChange={handleImageChange} />

        <select
          value={style}
          onChange={(e) => setStyle(e.target.value)}
          style={{ width: "100%", padding: "0.5rem", marginTop: "1rem" }}
        >
          <option value="Ghibli">Studio Ghibli</option>
          <option value="Pixar">Pixar</option>
          <option value="Anime">Anime</option>
          <option value="Cyberpunk">Cyberpunk</option>
          <option value="Sketch">Sketch</option>
        </select>

        <button
          onClick={handleGenerate}
          disabled={loading}
          style={{
            marginTop: "1rem",
            padding: "0.5rem 1rem",
            backgroundColor: "#6366f1",
            color: "#fff",
            border: "none",
            borderRadius: "4px",
            cursor: "pointer"
          }}
        >
          {loading ? "Generating..." : "Generate Image"}
        </button>
      </div>

      {result && (
        <div style={{ marginTop: "2rem" }}>
          <h2 style={{ fontSize: "20px", marginBottom: "1rem" }}>Generated Image</h2>
          <img src={result} alt="Styled result" style={{ width: "100%", borderRadius: "8px" }} />
        </div>
      )}
    </div>
  );
}
