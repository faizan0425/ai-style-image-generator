import React, { useState } from "react";

export default function App() {
  const [image, setImage] = useState(null);
  const [style, setStyle] = useState("Ghibli");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleImageChange = (e) => {
    setImage(e.target.files[0]);
    setResult(null);
  };

  const handleGenerate = async () => {
    if (!image) return;
    setLoading(true);

    // Placeholder for AI API integration
    setTimeout(() => {
      setResult("/placeholder-result.jpg");
      setLoading(false);
    }, 2000);
  };

  return (
    <div style={{ padding: '2rem', maxWidth: '600px', margin: 'auto' }}>
      <h1 style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '1rem' }}>
        AI Style Image Generator
      </h1>

      <div style={{ marginBottom: '1rem' }}>
        <input type="file" accept="image/*" onChange={handleImageChange} />
      </div>

      <div style={{ marginBottom: '1rem' }}>
        <select
          value={style}
          onChange={(e) => setStyle(e.target.value)}
          style={{ width: '100%', padding: '0.5rem', borderRadius: '5px' }}
        >
          <option value="Ghibli">Studio Ghibli</option>
          <option value="Pixar">Pixar</option>
          <option value="Anime">Anime</option>
          <option value="Cyberpunk">Cyberpunk</option>
          <option value="Sketch">Sketch</option>
        </select>
      </div>

      <button onClick={handleGenerate} disabled={loading} style={{
        padding: '0.75rem 1.5rem',
        background: '#4f46e5',
        color: '#fff',
        border: 'none',
        borderRadius: '5px',
        cursor: loading ? 'not-allowed' : 'pointer'
      }}>
        {loading ? "Generating..." : "Generate Image"}
      </button>

      {result && (
        <div style={{ marginTop: '2rem' }}>
          <h2 style={{ fontSize: '1.25rem', fontWeight: '600' }}>Generated Image</h2>
          <img src={result} alt="Styled result" style={{ marginTop: '1rem', borderRadius: '12px', boxShadow: '0 2px 12px rgba(0,0,0,0.15)' }} />
        </div>
      )}
    </div>
  );
}